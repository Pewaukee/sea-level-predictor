import pandas as pd
import matplotlib.pyplot as plt
from scipy.stats import linregress
import numpy as np

def draw_plot():
    # Read data from file
    df = pd.read_csv('epa-sea-level.csv')

    # make figure
    fig = plt.figure()
    ax = fig.add_subplot(111)

    # Create scatter plot
    ax.scatter(x=df['Year'], y=df['CSIRO Adjusted Sea Level'])

    # Create first line of best fit
    # idea from https://stackoverflow.com/questions/49192667/how-to-draw-a-line-through-a-scatter-graph-with-no-overflow
    # using iteration and lists, also recognizing the use of
    # xlim as a range argument and a valid arg for x
    line_1 = linregress(x=df['Year'], y=df['CSIRO Adjusted Sea Level'])
    ax.plot(range(1880, 2051), [line_1.intercept + line_1.slope * i for i in range(1880, 2051)], color='r')

    # Create second line of best fit
    # year should be >=2000
    line_2 = linregress(x=df.loc[df['Year'] >= 2000]['Year'], y=df.loc[df['Year'] >= 2000]['CSIRO Adjusted Sea Level'])
    ax.plot(range(2000, 2051), [line_2.intercept + line_2.slope * i for i in range(2000, 2051)], color='b')

    ax.set_xlim((1850, 2075))
    ax.set_ylim((-1, line_2.intercept+line_2.slope*2050))  # line_2, with higher slope will have higher y bound

    ax.set_xticks([(1850+25*i) for i in range(0, 10)])

    # Add labels and title
    plt.xlabel('Year')
    plt.ylabel('Sea Level (inches)')
    plt.title('Rise in Sea Level')
    
    # Save plot and return data for testing (DO NOT MODIFY)
    plt.savefig('sea_level_plot.png')
    return plt.gca()